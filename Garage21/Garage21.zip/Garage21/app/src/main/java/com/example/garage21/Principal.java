package com.example.garage21;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Principal extends AppCompatActivity {

    EditText placa, numero_vaga, preco_total;
    Button cadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        placa = findViewById(R.id.edtPlaca);
        numero_vaga = findViewById(R.id.edtNumeroVaga);
        preco_total = findViewById(R.id.edtPrecoTotal);

        cadastrar = findViewById(R.id.btnCadastrar);

        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastrar();
            }
        });
    }

    public void cadastrar()
    {
        Carro c = new Carro();

        c.setPlaca(placa.getText().toString());
        c.setNumero_vaga(numero_vaga.getText().toString());
        c.setPreco_total(Float.parseFloat(preco_total.getText().toString()));

        Toast.makeText(getApplicationContext(), "Cheguei aqui!", Toast.LENGTH_LONG).show();

        BancoGaragem.getBancodeDados(this).getDAO().insereCarro(c);

        Toast.makeText(getApplicationContext(), "Cadastrado com sucesso!", Toast.LENGTH_LONG).show();
    }
}